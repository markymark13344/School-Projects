from django import forms
from .models import FinanceAccount, Stock, Property, Bond, Expenditure, Income

class userForm(forms.ModelForm):
    class Meta:
        model = FinanceAccount
        fields = ('FirstName','LastName','Address','Age','Gender','family_id')
         
        widgets = {
            'FirstName': forms.TextInput(attrs={'class': 'form-control'}),
            'LastName' : forms.TextInput(attrs={'class': 'form-control'}),
            'Address' : forms.TextInput(attrs={'class': 'form-control'}),
            'Gender' : forms.Select(attrs={'class':'form-control'}),
            'family_id' : forms.TextInput(attrs={'class':'form-control'}),
        }

class StockForm(forms.ModelForm):
    class Meta:
        model = Stock
        fields = ['agent','amountBought']

        widgets = {
            'agent' : forms.Select(attrs={'class':'form-control'}),
            'amountBought' : forms.NumberInput(attrs={'class':'form-control'}),
        }

class PropertyForm(forms.ModelForm):
    class Meta:
        model = Property
        fields = ['value','address','agent']

        widgets = {
            'value' : forms.NumberInput(attrs={'class':'form-control'}),
            'address' : forms.TextInput(attrs={'class':'form-control'}),
            'agent' : forms.Select(attrs={'class':'form-control'}),
        }

class BondForm(forms.ModelForm):
    
    class Meta:
        model = Bond
        fields = ['agent','bond_yield','bond_maturity_date','bond_rating']

        widgets = {
            'agent' : forms.Select(attrs={'class':'form-control'}),
            'bond_yield' : forms.NumberInput(attrs={'class':'form-control'}),
            'bond_maturity_date' : forms.DateInput(attrs={'class':'form-control'}),
            'bond_rating' : forms.Select(attrs={'class':'form-control'}),
        }

class stockTransaction(forms.ModelForm):
    
    class Meta:
        model = Stock
        fields = ['status']

        widgets = {
            'status' : forms.Select(attrs={'class':'form-control'}),
        }


class expenditureForm(forms.ModelForm):
    class Meta:
        model = Expenditure
        fields = ['type','price','date','desc']

        widgets = {
            'type' : forms.Select(attrs={'class':'form-control'}),
            'price' : forms.NumberInput(attrs={'class':'form-control'}),
            'date' : forms.DateInput(format='%m/%d/%Y'),
            'desc' : forms.TextInput(attrs={'class': 'form-control'}),
        }

class IncomeForm(forms.ModelForm):
    class Meta:
        model = Income
        fields = ['amount','date']

        widgets = {
            'amount' : forms.NumberInput(attrs={'class':'form-control'}),
            'date' : forms.DateInput(format='%m/%d/%Y'),
        }
    


