from django.shortcuts import render
from django.views.generic import CreateView, UpdateView
from .models import Stock, Property, Bond, FinanceAgent, Expenditure, Income
from .forms import StockForm, PropertyForm, BondForm, stockTransaction, expenditureForm, IncomeForm
from django.contrib import messages
from django.urls import reverse_lazy
import yfinance as yf
import pandas_datareader as pdr
import datetime

# Create your views here.

def stock(request):

    if request.method == 'POST':
            ticker = request.POST['ticker']
            startDate = request.POST['startDate']
            endDate = request.POST['endDate']
            SMA = request.POST['SMA']

            if(ticker == None or ticker == ''):
                 return render(request,'stock.html',{'ticker' : "Please Enter a valid ticker"})

            if(ticker != None and ticker != ''):
                api_request = yf.Ticker(ticker).info
                request.session['api'] = api_request

            if(startDate != '' and endDate != ''):
                splitter = startDate.split('-')
                formatted = datetime.date(int(splitter[0]),int(splitter[1]),int(splitter[2]))
                formattedCopy = formatted
                splitter2 = endDate.split('-')
                formatted2 = datetime.date(int(splitter2[0]),int(splitter2[1]),int(splitter2[2]))
                delta = formatted2 - formattedCopy
                days = delta.days - 1

                labels = []
                data = []
                
                api_name = api_request
                api_dated = pdr.get_data_yahoo(ticker,startDate,endDate)
                for i in api_dated['Close']:
                    data.append(int(i))
                    formatted += datetime.timedelta(days=1)
                    labels.append(formatted.strftime("%m/%d/%Y"))
                  
                if(SMA != "" and SMA != None and int(SMA)<days):
                    data2 = []
                    altered = api_dated['Close'].rolling(int(SMA)).mean()
                    altered.dropna(inplace=True)
                    for i in altered:
                        data2.append(i)

                    return render(request,'stock.html',{'labels':labels,'data2':data,'SMA':data2,"api_name":api_name})



                



                return render(request,'stock.html',{'labels':labels, 'data':data,"api_name":api_name})
        
            

            return render(request,'stock.html',{'api': api_request})


    else:
        return render(request,'stock.html',{'ticker' : "Please Enter a ticker"})


def financeManager(request):
    managers = FinanceAgent.objects.all()
    if request.method == 'POST':
        if(request.POST['names'] != ''):
            name = str(request.POST['names']).split()

            fName = name[0]
            lName = name[1]
            manager = FinanceAgent.objects.get(FirstName=fName, LastName=lName)
            stocks =manager.stock_set.all()
            bonds = manager.bond_set.all()
            property = manager.property_set.all()
            
            
            return render(request,'search_finance.html',{'managers':managers,'manager':manager, 'stocks' : stocks,"bonds":bonds,"property":property})
        else:
            return render(request,'search_finance.html',{'Error' : "Invalid Manager Name: Use autofill to help"})
    return render(request, 'search_finance.html', {'managers':managers})

def stockValue(request):
    user = request.user
    stocks = user.stock_set.all()
    ownStocks = []
    soldStocks = []
    gainLoss = []
    for stock in stocks:
        if(stock.status == 'Own'):
            ownStocks.append(stock)
            temp = yf.Ticker(stock.ticker).info['currentPrice']
            gainLoss.append(round(float(stock.priceBought) - float(temp),2))
        else:
            soldStocks.append(stock)

    print(gainLoss)
    
    return render(request,'gain_loss.html',{'stock':ownStocks,'newValues':gainLoss,'soldStock':soldStocks})


def searchExpenses(request):
    Expenses = Expenditure.objects.filter(user=request.user)
    if request.method == 'POST':
        if(request.POST['startDate'] != '' and request.POST['endDate'] != ''):
            output = []
            splitter1 = request.POST['startDate'].split('-')
            formatted = datetime.date(int(splitter1[0]),int(splitter1[1]),int(splitter1[2]))

            splitter2 = request.POST['endDate'].split('-')
            formatted2 = datetime.date(int(splitter2[0]),int(splitter2[1]),int(splitter2[2]))

            if(formatted2 >= formatted):
                for i in Expenses:
                    if(i.date >= formatted and i.date <= formatted2):
                        output.append(i)
                return render(request,'search_expenses.html', {'output':output})
                
        else:
            return render(request,'search_expenses.html',{'Error' : "Could not find any data with given range"})
    return render(request, 'search_expenses.html', {'default' : 'Please Enter Date Range'})


         


class AddStock(CreateView):
    model = Stock
    template_name = 'add_stock.html'
    form_class = StockForm
    def form_valid(self,form):
        api_request = self.request.session['api']
        form.instance.owner = self.request.user
        form.instance.StockName = api_request['longName']
        form.instance.ticker = api_request['symbol']
        form.instance.priceBought = api_request['currentPrice']
        return super().form_valid(form)

    success_url = reverse_lazy('home')

class AddProperty(CreateView):
    model = Property
    template_name = 'add_property.html'
    form_class = PropertyForm
    def form_valid(self,form):
        form.instance.owner = self.request.user
        return super().form_valid(form)

class AddBond(CreateView):
    model = Bond
    template_name = 'add_bond.html'
    form_class = BondForm
    def form_valid(self,form):
        form.instance.owner = self.request.user
        return super().form_valid(form)

class sellStock(UpdateView):
    model = Stock
    template_name = 'sell_stock.html'
    form_class = stockTransaction
    success_url = reverse_lazy('home')
    def form_valid(self,form): 
        form.instance.status = 'sold'
        return super().form_valid(form)
    
class AddExpense(CreateView):
    model = Expenditure
    template_name = 'add_expense.html'
    form_class = expenditureForm
    success_url = reverse_lazy('home')
    def form_valid(self,form):
        form.instance.user = self.request.user
        return super().form_valid(form)

class AddIncome(CreateView):
    model = Income
    template_name = 'add_income.html'
    form_class = IncomeForm
    success_url = reverse_lazy('home')
    def form_valid(self,form):
        form.instance.user = self.request.user
        return super().form_valid(form)

def pie_chart(request):
    labels = []
    data = []
    foodprice = 0
    healthprice = 0
    entertainmentprice = 0
    mortageprice = 0
    vehicleprice = 0
    insuranceprice = 0
    otherprice = 0



    query = Expenditure.objects.filter(user=request.user)
    
    for item in query:
        if(item.type == 'Food'):
            foodprice += item.price
        elif(item.type == 'Health'):
            healthprice += item.price
        elif(item.type == 'Entertainment'):
            entertainmentprice += item.price
        elif(item.type == 'Mortage and Utilities'):
            mortageprice += item.price
        elif(item.type == 'Vehicle'):
            vehicleprice += item.price
        elif(item.type == 'Insurances'):
            insuranceprice += item.price
        else:
            otherprice += item.price


    if(foodprice > 0):
        data.append(int(foodprice))
        labels.append('Food')
    if(healthprice > 0):
        data.append(int(healthprice))
        labels.append('Health')
    if(entertainmentprice > 0):
        data.append(int(entertainmentprice))
        labels.append('Entertainment')
    if(mortageprice > 0):
        data.append(int(mortageprice))
        labels.append('Mortage and Utilities')
    if(vehicleprice > 0):
        data.append(int(vehicleprice))
        labels.append('Vehicle')
    if(insuranceprice > 0):
        data.append(int(insuranceprice))
        labels.append('Insurances')
    if(otherprice > 0):
        data.append(int(otherprice))
        labels.append('Other')

       
    return render(request, 'expense_overview.html', {'labels' : labels, 'data' : data})

def AccountOverview(request):
    incomearray = []
    expensearray = []
    stockarray = []

    today = datetime.date.today()
    stocks = Stock.objects.filter(owner=request.user)
    income = Income.objects.filter(user=request.user)
    expenses = Expenditure.objects.filter(user=request.user)


    for i in range(1,13):
        totalstock = 1
        totalincome = 1 
        totalexpenses = 1
        for stock in stocks:
            if(stock.dateBought.year == today.year and stock.dateBought.month == i):
                totalstock += stock.priceBought
        for expense in expenses:
            if(expense.date.year == today.year and expense.date.month == i):
                totalexpenses += expense.price
        for n in income:
            if(n.date.year == today.year and n.date.month == i):
                totalincome += n.amount
        incomearray.append(int(totalincome))
        expensearray.append(int(totalexpenses))
        stockarray.append(int(totalstock))

        print(totalexpenses)

    return render(request,'account_overview.html',{'stock': stockarray, 'income' : incomearray, 'expense' : expensearray})


def totalMonthlyIncome(request):
    incomes = Income.objects.filter(user = request.user)
    totalIncome = 0
    today = datetime.date.today()
    for income in incomes:
        if(income.date.month == today.month):
            totalIncome += income.amount
    return totalIncome
        
            
    









    


