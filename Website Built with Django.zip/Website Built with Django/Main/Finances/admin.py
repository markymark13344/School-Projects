from django.contrib import admin

from .models import FinanceAccount, Stock, FinanceAgent,Property,Bank,Bond, Expenditure

# Register your models here.
admin.site.register(FinanceAccount)
admin.site.register(FinanceAgent)
admin.site.register(Stock)
admin.site.register(Property)
admin.site.register(Bank)
admin.site.register(Bond)
admin.site.register(Expenditure)