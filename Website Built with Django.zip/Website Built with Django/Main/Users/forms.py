from django import forms
from Finances.models import FinanceAccount

class FinanceAccountForm(forms.ModelForm):
    class Meta:
        model = FinanceAccount
        fields = ('FirstName','LastName','Address','Age','Gender','family_id')

        widgets = {
            'FirstName': forms.TextInput(attrs={'class': 'form-control'}),
            'LastName' : forms.TextInput(attrs={'class': 'form-control'}),
            'Address' : forms.TextInput(attrs={'class': 'form-control'}),
            'Age' : forms.TextInput(attrs={'class': 'form-control'}),
            'Gender': forms.Select(attrs={'class': 'form-control'}),
            'family_id' : forms.TextInput(attrs={'class': 'form-control'}),

     }