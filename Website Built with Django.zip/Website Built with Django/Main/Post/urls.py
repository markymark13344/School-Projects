from platform import architecture
from django.urls import path
#from . import views
from .views import DeletePost, HomeView,ArticleDetail,AddPost, UpdatePost,AddComment, AddFile
from . import views
urlpatterns = [
    path('', HomeView.as_view(), name="home"),
    path('article/<int:pk>', ArticleDetail.as_view(), name='article'),
    path('add_post/', AddPost.as_view(), name='add_post'),
    path('article/edit/<int:pk>', UpdatePost.as_view(), name="update_post"),
    path('article/delete/<int:pk>', DeletePost.as_view(), name="delete_post"),
    path('article/comment/<int:pk>', AddComment.as_view(), name="add_comment"),
    path('article/upload/<int:pk>', AddFile.as_view(), name="add_file"),
]