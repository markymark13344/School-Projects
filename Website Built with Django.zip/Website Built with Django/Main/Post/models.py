from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse
import datetime 
from datetime import date

def count_post_of(self):
        return Post.objects.count()

# Create your models here.

class Post(models.Model):
    title = models.CharField(max_length=255)
    title_tag = models.CharField(max_length=255)
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    body = models.TextField()
    post_date = models.DateField(auto_now_add=True)



    def __str__(self):
        return self.title + '|' + str(self.author)

    def get_absolute_url(self):
        return reverse('home')

    @property
    def is_new(self):
        return date.today() == self.post_date

    

class Comment(models.Model):
    post = models.ForeignKey(Post,on_delete=models.CASCADE, related_name="comments")
    Title = models.CharField(max_length=255)
    body = models.TextField()
    date_added = models.DateTimeField(auto_now_add=True)

    def __str__(self):
       return '%s - %s' % (self.post.title, self.name)

class BlogFiles(models.Model):
    post = models.ForeignKey(Post,on_delete=models.CASCADE, related_name="files")
    title = models.CharField(max_length=255)
    file = models.FileField(upload_to='projectfiles/%Y/%m/%d/')
    date_added = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return '%s - %s' % (self.post.title, self.title)
    
    def get_absolute_url(self):
        return reverse('home')

    
