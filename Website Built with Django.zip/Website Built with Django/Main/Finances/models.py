from django.db import models
from django.shortcuts import render
from django.contrib.auth.models import User
from django.core.validators import MaxValueValidator,MinValueValidator
from django.urls import reverse
from datetime import date
from django.utils.crypto import get_random_string
import datetime as dt



# Create your models here.

STATUS_CHOICES = {
    ('Own', 'Own'),
    ('Sold', 'Sold')
}

class FinanceAgent(models.Model):
    FirstName = models.CharField(max_length = 50)
    LastName = models.CharField(max_length = 50)
    Firm = models.TextField(default="None")
    ProcessingFee = models.IntegerField()

    def __str__(self):
        if(self.id == 1):
            return "No Manager"
        else:
            return self.FirstName +  " " + self.LastName + ":" + self.Firm
   

class FinanceAccount(models.Model):
    GENDER_CHOICES = (
        ('MALE','Male'),
        ('FEMALE','Female'),
        ('OTHER','Other'),
    )

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    FirstName = models.CharField(max_length = 50)
    LastName = models.CharField(max_length = 50)
    Address = models.CharField(max_length=50)
    Age = models.IntegerField(validators=[MaxValueValidator(120),MinValueValidator(18)])
    Gender = models.CharField(max_length=10,choices=GENDER_CHOICES)
    family_id = models.CharField(max_length=32, default=get_random_string(32))

    def hasUser(request):
        userReq = request.user
        if(FinanceAccount.objects.filter(user=userReq) != None ):
            return True
        else:
            return False
        

    def __str__(self):
        return str(self.user) 

    def get_absolute_url(self):
        return reverse('home')


class Bank(models.Model):
    loan_rate = models.FloatField()
    Name = models.CharField(max_length=255)

    def get_absolute_url(self):
       return reverse('home')

class Stock(models.Model):
    def get_default():
        return FinanceAgent.objects.get(id=1)


    ticker = models.CharField(max_length=10)
    StockName = models.CharField(max_length=255)
    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    agent = models.ForeignKey(FinanceAgent, on_delete=models.SET_DEFAULT, default=get_default)
    priceBought = models.FloatField()
    amountBought = models.FloatField()
    dateBought = models.DateField(default = date.today)
    status = models.CharField(max_length=50, default='Own',choices=STATUS_CHOICES)





    def __str__(self):
        return "Ticker:" + self.ticker + "-- Name: " + self.StockName

class Property(models.Model):
    def get_default():
        return FinanceAgent.objects.get(id=1)

    owner = models.ForeignKey(User,on_delete=models.CASCADE)
    value = models.FloatField()
    agent = models.ForeignKey(FinanceAgent, on_delete=models.CASCADE)
    address = models.CharField(max_length = 255)
    status = models.CharField(max_length=50, default='Own',choices=STATUS_CHOICES)

    def get_absolute_url(self):
       return reverse('home')

class Bond(models.Model):
    RATING_CHOICES = {
        ('AAA','AAA'),
        ('AA+','AA+'),
        ('AA','AA'),
        ('AA-','AA-'),
        ('A+','A+'),
        ('A','A'),
        ('A-','A-'),
        ('BBB+','BBB+'),
        ('BBB','BBB'),
        ('BBB-','BBB-'),
    }
    def get_default():
        return Bank.objects.get(id=1)

    owner = models.ForeignKey(User,on_delete=models.CASCADE)
    agent = models.ForeignKey(FinanceAgent, on_delete=models.CASCADE)
    issuer = models.ForeignKey(Bank, on_delete=models.SET_DEFAULT, default=get_default)
    bond_yield = models.FloatField()
    bond_maturity_date = models.DateField()
    bond_rating = models.CharField(max_length=255, choices=RATING_CHOICES)
    status = models.CharField(max_length=50, default='Own',choices=STATUS_CHOICES)

    def get_absolute_url(self):
       return reverse('home')

class Expenditure(models.Model):
    TYPE_CHOICES = {
        ('Food','Food'),
        ('Health','Health'),
        ('Entertainment','Entertainment'),
        ('Mortage and Utilities','Mortage and Utilities'),
        ('Vehicle','Vehicle'),
        ('Insurances','Insurances'),
        ('Other','Other'),
    }

    user = models.ForeignKey(User,on_delete=models.CASCADE)
    type = models.CharField(max_length=255,choices=TYPE_CHOICES)
    price = models.DecimalField(validators=[MaxValueValidator(9999999),MinValueValidator(0.01)],decimal_places=2,max_digits=10)
    date = models.DateField()
    desc = models.CharField(max_length=255)

  

class Income(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    amount = models.DecimalField(validators=[MaxValueValidator(9999999),MinValueValidator(0.01)],decimal_places=2,max_digits=10)
    date = models.DateField()

    
    









   








