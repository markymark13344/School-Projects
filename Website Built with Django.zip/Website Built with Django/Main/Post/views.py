from xml.etree.ElementTree import Comment
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from .models import Post, BlogFiles
from .forms import PostForm, UpdateForm, CommentForm
from django.urls import reverse_lazy
from django.shortcuts import render
from hitcount.views import HitCountDetailView
from Finances.models import Income, Expenditure
import datetime as dt



# Create your views here.
#def home(request):
#   return render(request, 'home.html', {})



class HomeView(ListView):
    model = Post
    template_name = 'home.html'
    ordering = ['-post_date']

    def get(self,request):
        incomes = Income.objects.filter(user = request.user)
        expenses = Expenditure.objects.filter(user = request.user)
        totalIncome = 0
        totalExpense = 0
        for income in incomes:
            if(income.date.month == dt.date.today().month):
                totalIncome += income.amount
        for expense in expenses:
            if(expense.date.month == dt.date.today().month):
                totalExpense += expense.price

        difference = totalIncome - totalExpense
        
        return render(request,self.template_name,{'NetBalance': difference})

    
class ArticleDetail(HitCountDetailView):
    model = Post
    template_name = 'art_detail.html'
    count_hit = True

class AddPost(CreateView):
    model = Post
    form_class = PostForm
    template_name = 'add_post.html'
    #fields = '__all__'
    def form_valid(self,form):
                form.instance.author = self.request.user
                return super().form_valid(form)

class AddComment(CreateView):
    model = Comment
    template_name = 'add_com.html'
    form_class = CommentForm
    success_url = reverse_lazy('home')
    def form_valid(self,form):
        form.instance.post_id = self.kwargs['pk']
        return super().form_valid(form)

class UpdatePost(UpdateView):
    model = Post
    form_class = UpdateForm
    template_name = 'update_post.html'
    #fields = ['title','title_tag','body']    

class DeletePost(DeleteView):
    model = Post
    template_name = 'delete_post.html'
    success_url = reverse_lazy('home')

class AddFile(CreateView):
    model = BlogFiles
    template_name = 'upload.html'
    fields = ('title','file')
    success_url = reverse_lazy('home')
    def form_valid(self,form):
        form.instance.post_id = self.kwargs['pk']
        return super().form_valid(form)
    



    




