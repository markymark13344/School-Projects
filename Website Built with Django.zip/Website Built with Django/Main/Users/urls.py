from platform import architecture
from django.urls import path
from .views import UserRegister, CreateFinanceAccount, UpdateFinanceAccount

urlpatterns = [
    path('register/', UserRegister.as_view(), name='register'),
    path('register/create_finance_account',CreateFinanceAccount.as_view(),name='create_finance_account'),
    path('register/update_finance_account/<int:pk>', UpdateFinanceAccount.as_view(), name='update_finance_account'),
]