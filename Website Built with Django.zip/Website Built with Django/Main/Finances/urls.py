
from django.urls import path,include
from django.conf import settings
from django.conf.urls.static import static
from . import views
from .views import AddStock, AddProperty, AddBond, sellStock, AddExpense, AddIncome

urlpatterns = [
    path('stock', views.stock,name='stock_page'),
    path('add_stock', AddStock.as_view(), name='add_stock'),
    path('add_property', AddProperty.as_view(), name='add_property'),
    path('add_bond', AddBond.as_view(),name='add_bond'),
    path('search_manager', views.financeManager, name='search_manager'),
    path('search_expense',views.searchExpenses,name='search_expense'),
    path('gain_loss',views.stockValue, name='gain_loss'),
    path('sell_stock/<int:pk>', sellStock.as_view(), name='sell_stock'),
    path('add_expenditure', AddExpense.as_view(), name='add_expense'),
    path('expense_report', views.pie_chart, name='expense_report'),
    path('account_overview', views.AccountOverview, name='account_overview'),
    path('add_income', AddIncome.as_view(),name='add_income'),
] 
