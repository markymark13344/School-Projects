from audioop import reverse
from django.shortcuts import render
from django.views import generic
from django.views.generic import CreateView, UpdateView
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from Finances.models import FinanceAccount
from .forms import FinanceAccountForm

# Create your views here.

class UserRegister(generic.CreateView):
        form_class = UserCreationForm
        template_name = 'registration/register.html'
        success_url = reverse_lazy('login')

class CreateFinanceAccount(CreateView):
        model = FinanceAccount
        template_name = "registration/create_finance_account.html"
        form_class = FinanceAccountForm

        def form_valid(self,form):
                form.instance.user = self.request.user
                return super().form_valid(form)


class UpdateFinanceAccount(UpdateView): 
        model = FinanceAccount
        template_name = "registration/update_finance_account.html"
        form_class = FinanceAccountForm
        success_url = reverse_lazy('home')
        


